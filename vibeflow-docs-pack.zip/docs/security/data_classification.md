# Data Classification

- PUBLIC, INTERNAL, CONFIDENTIAL, SENSITIVE
Gateway enforces: redact secrets; deny external calls for SENSITIVE unless allow‑listed.
