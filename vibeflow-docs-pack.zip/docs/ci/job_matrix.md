# CI Job Matrix (MVP)

- lint+typecheck (node@20)
- unit (node@20)
- schema‑validate (ajv on ./contracts)
- docs‑link‑check (markdown)
- optional: e2e (playwright)
