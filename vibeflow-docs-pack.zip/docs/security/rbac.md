# RBAC (roles)

- admin, maintainer, reviewer, operator, viewer
Enforce at Gateway, API, and Dashboard; audit all role changes.
