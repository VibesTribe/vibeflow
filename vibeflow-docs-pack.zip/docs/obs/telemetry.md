# Telemetry Fields (RunMetric/Event)

- trace_id, task_id, slice_id
- platform, model, tokens_prompt, tokens_output, cost_usd
- latency_ms, success, retries, error_code
- validation_passed, review_policy, provenance
