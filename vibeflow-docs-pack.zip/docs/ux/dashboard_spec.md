# Dashboard Spec (MVP)

- Cards per task with stage, status, confidence, provenance, review buttons
- Global progress, per‑slice progress
- DAG graph per slice; filter/search
- Approvals: visual_agent, human, merge_gate; audit log panel
