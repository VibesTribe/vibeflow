# Contracts

- JSON Schema Draft 2020-12 ($id at vibeflow.dev paths).
- Policy: additive-only; bump `$id` when breaking.
- Validated in CI (see `.github/workflows/docs-validate.yml`).
